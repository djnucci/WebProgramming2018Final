<?php  
    $table = "movies";

    $querys = array("start_time", "end_time","movie_name","age_rating","room_ID","total_seats","taken_seats","row_a_seats","row_b_seats","row_c_seats","3D");
    $startTime = $endTime = $movieName = $ageRating = $roomID = $totalSeats = $takenSeats = $rowASeats = $rowBSeats = $rowCSeats = $is3D;

    include "config.php";

?>